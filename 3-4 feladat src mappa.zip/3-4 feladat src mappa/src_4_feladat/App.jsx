import { useState } from 'react'
import App1 from "./Calculator";
import App2 from "./TicTacToe";

function App() {
  const [menu, setMenu] = useState("app1");
  return (
    <div>
      
      <nav>
        <button className={menu === "app1" ? "spa-btn" : "spa-btn btn-secondary"}onClick={() => setMenu("app1")}>Számológép</button> 
        <button className={menu === "app2" ? "spa-btn" : "spa-btn btn-secondary"}onClick={() => setMenu("app2")}>Amőba</button>
      </nav>
      <hr />
      {menu === "app1" && <App1 />}
      {menu === "app2" && <App2 />}
    </div>
  );
}
export default App

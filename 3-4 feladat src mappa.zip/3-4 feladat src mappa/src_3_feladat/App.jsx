import React, { useState } from "react";
import UserTable from "./tables/UserTable";
import EditUserForm from "./forms/EditUserForm";
import AddUserForm from "./forms/AddUserForm";

const App = () => {
  const racesData = [
    { id: 1, datum: "1994.05.15", nev: "Monacoi",    helyszin: "Monaco" },
    { id: 2, datum: "1979.07.14", nev: "Brit",      helyszin: "Nagy-Britannia" },
    { id: 3, datum: "1976.07.18", nev: "Brit",       helyszin: "Nagy-Britannia" },
    { id: 3, datum: "1994.07.31", nev: "Német",       helyszin: "Németország" },
    { id: 3, datum: "1978.09.10", nev: "Olasz",       helyszin: "Olaszország" },
  ];

  const [races, setRaces]           = useState(racesData);
  const [currentRace, setCurrentRace] = useState("");
  const [editing, setEditing]       = useState(false);

  const addRace = race => {
    race.id = races.length + 1;
    setRaces([...races, race]);
  };

  const deleteRace = id => {
    setEditing(false);
    setRaces(races.filter(race => race.id !== id));
  };

  const editRow = race => {
    setEditing(true);
    setCurrentRace(race);
  };

  const updateRace = (id, updatedRace) => {
    setEditing(false);
    setRaces(races.map(race => (race.id === id ? updatedRace : race)));
  };

  return (
    <div className="content-wrapper">
      <h2 className="page-title"> React CRUD</h2>

      <div className="form-box">
        <h3 style={{ color: "var(--accent)", fontFamily: "var(--font-display)", textTransform: "uppercase", marginBottom: "0.5rem" }}>
          {editing ? " Futam szerkesztése" : " Új futam hozzáadása"}
        </h3>
        {!editing ? (
          <AddUserForm addRace={addRace} />
        ) : (
          <EditUserForm
            setEditing={setEditing}
            currentRace={currentRace}
            setCurrentRace={setCurrentRace}
            updateRace={updateRace}
          />
        )}
      </div>

      <UserTable races={races} editRow={editRow} deleteRace={deleteRace} />
    </div>
  );
};

export default App;

import React from "react";

const UserTable = ({ races, editRow, deleteRace }) => (
  <table className="list">
    <thead>
      <tr>
        <th>Dátum</th>
        <th>Futam neve</th>
        <th>Helyszín</th>
        <th>Műveletek</th>
      </tr>
    </thead>
    <tbody>
      {races.length > 0 ? (
        races.map(race => (
          <tr key={race.id}>
            <td>{race.datum}</td>
            <td>{race.nev}</td>
            <td>{race.helyszin}</td>
            <td>
              <a onClick={() => editRow(race)}>Edit</a>
              <a onClick={() => {
                if (window.confirm("Biztosan törölni szeretnéd?")) deleteRace(race.id);
              }}>Delete</a>
            </td>
          </tr>
        ))
      ) : (
        <tr>
          <td colSpan={4}>Nincs futam az adatbázisban.</td>
        </tr>
      )}
    </tbody>
  </table>
);

export default UserTable;

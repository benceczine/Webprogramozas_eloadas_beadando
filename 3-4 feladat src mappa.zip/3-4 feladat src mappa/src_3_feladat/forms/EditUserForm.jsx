import React, { useState, useEffect } from "react";

const EditUserForm = ({ setEditing, currentRace, updateRace }) => {
  const [race, setRace] = useState(currentRace);

  const handleInputChange = event => {
    const { name, value } = event.target;
    setRace({ ...race, [name]: value });
  };

  useEffect(() => {
    setRace(currentRace);
  }, [currentRace]);

  return (
    <form onSubmit={event => {
      event.preventDefault();
      updateRace(race.id, race);
    }}>
      <div>
        <label>Dátum *</label>
        <input type="date" name="datum" value={race.datum} onChange={handleInputChange} />
      </div>
      <div>
        <label>Futam neve *</label>
        <input type="text" name="nev" value={race.nev} onChange={handleInputChange} placeholder="pl. Magyar Nagydíj" />
      </div>
      <div>
        <label>Helyszín *</label>
        <input type="text" name="helyszin" value={race.helyszin} onChange={handleInputChange} placeholder="pl. Budapest" />
      </div>
      <div className="form-action-buttons">
        <button type="submit">Mentés</button>
        <button type="button" className="btn-secondary" onClick={() => setEditing(false)}>Mégse</button>
      </div>
    </form>
  );
};

export default EditUserForm;

import React, { useState } from "react";

const AddUserForm = ({ addRace }) => {
  const [race, setRace] = useState({ datum: "", nev: "", helyszin: "" });

  const handleInputChange = event => {
    const { name, value } = event.target;
    setRace({ ...race, [name]: value });
  };

  return (
    <form onSubmit={event => {
      event.preventDefault();
      if (!race.datum || !race.nev || !race.helyszin) return;
      addRace(race);
      setRace({ datum: "", nev: "", helyszin: "" });
    }}>
      <div>
        <label>Dátum *</label>
        <input type="date" name="datum" value={race.datum} onChange={handleInputChange} />
      </div>
      <div>
        <label>Futam neve *</label>
        <input type="text" name="nev" value={race.nev} onChange={handleInputChange} placeholder="Futam Neve" />
      </div>
      <div>
        <label>Helyszín *</label>
        <input type="text" name="helyszin" value={race.helyszin} onChange={handleInputChange} placeholder="Helyszín" />
      </div>
      <div className="form-action-buttons">
        <button type="submit">Hozzáadás</button>
      </div>
    </form>
  );
};

export default AddUserForm;
